# InteriorFlux website

Static site (HTML/CSS/JS, no build step).

```
index.html
assets/images/  (3 photos)
.nojekyll
CONTENT.md      (all text/pricing/images reference)
```

## Host on GitHub Pages
1. Create a new repo on github.com (e.g. `interiorflux`), public.
2. Upload everything in this folder (drag and drop in "Add file → Upload files"), keeping the `assets` folder. Commit.
3. Repo → Settings → Pages → Source: "Deploy from a branch" → Branch: `main`, folder `/ (root)` → Save.
4. After about a minute the site is live at `https://<username>.github.io/interiorflux/`.

Command line alternative:
```
git init && git add . && git commit -m "InteriorFlux site"
git branch -M main
git remote add origin https://github.com/<username>/interiorflux.git
git push -u origin main
```
