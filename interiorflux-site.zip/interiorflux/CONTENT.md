# InteriorFlux – Website Content Reference

**Tagline:** Know the cost before you build.
**What it is:** Independent interior cost advisory in Bengaluru. Quote checks, budgets, milestone tracking. Flat fee, no commission, works only for the person paying.
**Site type:** Single-page site, 6 views switched by URL hash (#home, #services, #how-it-works, #pricing, #blog, #contact). Light/dark theme toggle (saved in browser).
**Font:** Poppins (Google Fonts). **Colours:** Teal #0F4C4A, Terracotta #D9734E, Sand #F4EEE6.

## Images (assets/images/)
| File | Used in | Alt text |
|---|---|---|
| home-living-area.jpg (1200x654) | Home → "Two ways in" → Homeowners tab | Open-plan living and dining area in a high-rise apartment with floor-to-ceiling windows |
| office-workspace.jpg (1200x654) | Home → "Two ways in" → Businesses tab | Open-plan office with long wooden desks, large windows and a meeting pod |
| sample-report.jpg (1408x768) | How it works → "What you will receive" | Sample report page with an annotated photo of an apartment living area |

## HOME
- **Hero:** "Know the cost before you build." + intro + input "Describe your project or paste a quote line" + button "Start a quote check"
- Chips: Is my quote complete? / What do you check? / What does it cost?
- Caption: Independent · Flat fee · No commission · Bengaluru
- Sample quote card (2 BHK, Whitefield): Materials ₹4,20,000 · Labour ₹1,85,000 · Finishing ₹95,000. Flags: "wardrobe hardware not named", "false ceiling area matches the plan"
- Scrolling strip: Homeowners, Remote owners, New-home buyers, Renovators, Businesses, Developers
- **Two ways in** (tabs):
  - Homeowners – "Planning a home or a renovation?" Check a contractor quote before you sign; Budget room by room, material by material; Approve milestones with fixed amounts; Keep your own contractor
  - Businesses – "Fitting out an office, shop or clinic?" Compare vendor quotes side by side; Set a CAPEX budget your finance team can follow; Track changes in scope with their cost; Read contracts before you sign
- **Why budget first** (stats): 27,968 homes sold in Bengaluru H1 2026 (Knight Frank) · 24% rise in avg price/sq ft Q1 2026 YoY (PropTiger) · 27,000 new homes launched Q1 2026 (JLL)
- **Three checks:** Budget audit · Quote verification · Milestone tracking
- **Three steps:** 1 Share floor plan/quote 2 We analyse costs, markups, gaps 3 Approve milestones and build
- Band: "We don't build. We don't sell interiors. We don't take commission."
- **FAQ (5):** Do you build or sell interiors? / Will you tell me whether a quote is fair? / Can I keep my contractor? / Can I pay per service or monthly? / Is there any other cost?
- CTA: "Have a quote in hand?" → Book a consultation

## SERVICES
- **Individuals:** Pre-construction quote audit (PDF report, 3 working days) · Residential design & material budgeting (itemised budget, 5 working days) · Milestone & execution tracking (checklist + photo update per stage)
- **Businesses:** Commercial fit-out quote review (5 working days) · CAPEX & project budgeting advisory · Vendor & contract oversight
- **Interior designers:** Room sketches & plans · Costed bills of quantities · Quote audits & vendor support
- Note on fairness: respects every kind of provider, from turnkey firms to independent carpenters.

## HOW IT WORKS
- 3-step scroll tracker with sample panels (received / analysis / milestones 30%-40%-30%)
- You receive: plain-language report; itemised budget (Vendor support & Advisory); 30-minute call; milestone plan (Advisory)
- Accepted files: PDF, JPG, XLSX up to 25 MB. Typical turnaround 3 working days.

## PRICING (flat fee, never % of project cost)
- **Homeowners:** Quote audit ₹12,500/quote · Vendor support ₹20,000/project · Design & budget plan ₹50,000/plan · Project oversight ₹75,000/project
- **Businesses:** Fit-out quote review from ₹12,500 · CAPEX advisory from ₹50,000 · Contract oversight from ₹75,000
- **Interior designers (monthly):** Starter ₹18,000 · Studio ₹60,000 (highlighted) · Practice ₹1,50,000. Per request: Room sketch ₹5,000/room
- Repeat orders: Practice plan ₹1,50,000/month. Custom estimates for larger homes and multi-site work.

## RESOURCES (blog cards, dated 12 Nov 2026)
1. Hidden costs in interior quotations (and how to spot them) – 6 min
2. Why you should budget before you build in Bengaluru – 5 min
3. Turnkey contractors vs. independent cost advisors – 4 min

## CONTACT
- Form: name, phone, email, I am a (Homeowner/Business/Interior designer), service, file upload, message
- Office: 12 Sample Road, Indiranagar, Bengaluru 560038 · Mon–Sat 10am–6pm
- Phone +91 80 0000 0000 · hello@interiorflux.in · WhatsApp +91 90000 00000

## Placeholders still to fill in
- Address, phone, email, WhatsApp are sample values
- `[₹ per outlet]`, `[x working days]`, `[x months]`, `[x]` revisions, `[GST: to be confirmed]`
- `[Map placeholder]` and 3 blog `[Cover image]` boxes
- Blog "Read article" links go nowhere yet; LinkedIn/Instagram/Privacy/Terms are plain text
- Contact form and the hero input do nothing real yet (the form only shows a thank-you message). Connect Formspree/Google Forms to receive enquiries.
